#include <iostream>

int main()
{
	long decimalNumber{ 0 }; //the end result
	long baseNumber{ 1 }; //base value. setting this to zero would mess up calculations
	long binaryNumber{ 0 }; //the number to be converted
	long lastDigit{ 0 }; //used to contain last digit of binaryNumber
	//longs instead of ints for bigger numbers

	std::cout << "Binary to Decimal converter\n\n"; //o: "Binary to Decimal converter(endline endline)"

	std::cout << "Please input a binary number: "; //o: "Please input a binary number: "
	std::cin >> binaryNumber; //input: binaryNumber

	while (binaryNumber) //Until binaryNumber reaches 0
	{
		lastDigit = binaryNumber % 10; //takes the remainder to find the last digit of binaryNumber

		binaryNumber = binaryNumber / 10; //divides binary number by 10

		decimalNumber += lastDigit * baseNumber; //adds the values of decimalNumber and lastDigit and multiplies that by current baseNumber

		baseNumber = baseNumber * 2; //moves on to next base number. 2 > 4 > 8 > etc.

	}

	std::cout << "The decimal equivalent is " << decimalNumber << ".\n"; //o: "The decimal equivalent is [decimalNumber].(endline)"
}
